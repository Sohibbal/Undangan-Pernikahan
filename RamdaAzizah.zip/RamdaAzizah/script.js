simplyCountdown('.simply-countdown-dark', {
  year: 2025, // Target year (required)
  month: 6, // Target month [1-12] (required)
  day: 5, // Target day [1-31] (required)
  hours: 8, // Target hour [0-23], default: 0
  words: { // Custom labels, with lambda for plurals
    days: { root: 'Hari', lambda: (root, n) => n > 1 ? root + '' : root },
    hours: { root: 'Jam', lambda: (root, n) => n > 1 ? root + '' : root },
    minutes: { root: 'Menit', lambda: (root, n) => n > 1 ? root + '' : root },
    seconds: { root: 'Detik', lambda: (root, n) => n > 1 ? root + '' : root }
  },
});